/* eslint-disable */
(function (n, t) {
  onload = function () {
    _G.BPT = new Date();
    !_w.sb_ppCPL && t && sb_st(function () {
      t(new Date());
    }, 0);
  }
    ;
}
)(_w.onload, _w.si_PP);
_w.rms.js(
  //{ 'A:rms:answers:Shared:BingCore.Bundle': '/rp/v-9MDlZf3UpTm3z78CHvLGE8SMU.gz.js' },
  { 'A:rms:answers:Shared:BingCore.Bundle': '/rp/a224OTR91R7nhnUp3RpvwJI8dVU.br.js' },
  //{ 'A:rms:answers:Web:FreeSydneyHelper': '/rp/cfhgV3_HFyB3URSxigzE0QzgsF8.br.js' },
  // { 'A:rms:answers:Web:SydneyFSCHelper': '/rp/wJbTArpXX7iY8vTObyrSJ0XZMCE.br.js' },
  //{ 'A:rms:answers:VisualSystem:ConversationScope': '/rp/ascyKFaOzJnUTZ_D-Mv819BZ0Go.br.js' },
  //{ 'A:rms:answers:CodexBundle:cib-bundle': '/rp/p6yM7JqIx0Y-tV67dzlhxRtdTkA.gz.js' },
  { 'A:rms:answers:CodexBundle:cib-bundle': '/rp/6JYDi9-2XVe6p7GjQcvfkzdAi_0.br.js' },
  { 'A:rms:answers:SharedStaticAssets:speech-sdk': '/rp/bll21ZO27j3KPE27uQBxt24c2Fw.br.js' },
  //{ 'A:rms:answers:Web:SydneyWelcomeScreenBase':'/rp/KgDPK_mKWjMgWe6o0SKA9dfE00Y.br.js' },
  //{ 'A:rms:answers:Web:SydneyWelcomeScreen':'/rp/sNzL8vfHHNmyqYOSQey9fNYd3kI.br.js' },
  { 'A:rms:answers:Web:SydneyFullScreenConv': '/rp/yuhncmz_MT-3TSF9a5y0wgIL43U.gz.js'},
  // { 'A:rms:answers:Web:ChatHomeScreenBase': '/rp/SlXkn2s3KjsnNrD80OtYBr8qECA.br.js' },
  // { 'A:rms:answers:Web:ChatHomeScreen': '/rp/x05EBLDKo9Gp0rV1W9OmmpoFp0o.br.js' },
);
