/* eslint-disable */
(function (n, t) {
  onload = function () {
    _G.BPT = new Date();
    !_w.sb_ppCPL && t && sb_st(function () {
      t(new Date());
    }, 0);
  }
    ;
}
)(_w.onload, _w.si_PP);
if (User_UCookieValue == null || User_UCookieValue == undefined || User_UCookieValue == '') {
  _w.rms.js(
    { 'A:rms:answers:Shared:BingCore.Bundle': '/rp/Pki1-YEXD6vos5MiDyyAeDq7sgs.br.js' },
    { 'A:rms:answers:Web:SydneyFSCHelper': '/rp/2gD9ZB2_GUiKjp2vDuIhvAfFK_k.br.js' },
    { 'A:rms:answers:VisualSystem:ConversationScope': '/rp/YyvH_4Cy-eJWBMjNigSPB7pENoc.br.js' },
   // { 'A:rms:answers:CodexBundle:cib-bundle': '/rp/P_rh3z1-a94XPvtoM6CCtPs2vjs.br.js' },
    { 'A:rms:answers:SharedStaticAssets:speech-sdk': '/rp/6slp3E-BqFf904Cz6cCWPY1bh9E.br.js' },
    { 'A:rms:answers:Web:SydneyWelcomeScreenBase':'/rp/_Eg7XX2el4yFXBdqXLVFaQjHxOM.br.js' },
    { 'A:rms:answers:Web:SydneyWelcomeScreen':'/rp/MT9w5YvjxYHdcyXSS0tDquzGw2Y.br.js' },
    { 'A:rms:answers:Web:SydneyFullScreenConv': '/rp/X75tNCeKFlgf3t1_IuCM8zL1kd0.br.js' },
  );
} else {
  _w.rms.js(
    { 'A:rms:answers:Shared:BingCore.Bundle': '/rp/Pki1-YEXD6vos5MiDyyAeDq7sgs.br.js' },
    { 'A:rms:answers:Web:SydneyFSCHelper': '/rp/2gD9ZB2_GUiKjp2vDuIhvAfFK_k.br.js' },
    { 'A:rms:answers:VisualSystem:ConversationScope': '/rp/YyvH_4Cy-eJWBMjNigSPB7pENoc.br.js' },
  //  { 'A:rms:answers:CodexBundle:cib-bundle': '/rp/kRRRe6dDU6pFoBOa7IXFkqE31qI.br.js' },
    { 'A:rms:answers:SharedStaticAssets:speech-sdk': '/rp/6slp3E-BqFf904Cz6cCWPY1bh9E.br.js' },
    { 'A:rms:answers:Web:SydneyWelcomeScreenBase':'/rp/_Eg7XX2el4yFXBdqXLVFaQjHxOM.br.js' },
    { 'A:rms:answers:Web:SydneyWelcomeScreen':'/rp/MT9w5YvjxYHdcyXSS0tDquzGw2Y.br.js' },
    { 'A:rms:answers:Web:SydneyFullScreenConv': '/rp/X75tNCeKFlgf3t1_IuCM8zL1kd0.br.js' },
  );
}