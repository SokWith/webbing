/* eslint-disable */
(function (n, t) {
  onload = function () {
    _G.BPT = new Date();
    !_w.sb_ppCPL && t && sb_st(function () {
      t(new Date());
    }, 0);
  }
    ;
}
)(_w.onload, _w.si_PP);
_w.rms.js(
  { 'A:rms:answers:Shared:BingCore.Bundle': '/rp/Pki1-YEXD6vos5MiDyyAeDq7sgs.br.js' },
  { 'A:rms:answers:Web:SydneyFSCHelper': '/rp/plViotfzKXF_pqqXx4NWn6aW_II.br.js' },
  { 'A:rms:answers:VisualSystem:ConversationScope': '/rp/YFRe970EMtFzujI9pBYZBGpdHEo.br.js' },
  { 'A:rms:answers:CodexBundle:cib-bundle': '/rp/h_z8hgmoir53hvshQQoyF7vDrYc.br.js' },
  { 'A:rms:answers:SharedStaticAssets:speech-sdk': '/rp/6slp3E-BqFf904Cz6cCWPY1bh9E.br.js' },
  { 'A:rms:answers:Web:SydneyWelcomeScreenBase':'/rp/tAJNECpUpSdBSxOEHv5jZ0nF93I.br.js' },
  { 'A:rms:answers:Web:SydneyWelcomeScreen':'/rp/H-Z1_dXpX8YW6Di4p6iwWmTVvMs.br.js' },
  { 'A:rms:answers:Web:SydneyFullScreenConv': '/rp/2BwrAKR2l9HZV6BTZonHj9yRnZ4.br.js' },
);