/* eslint-disable */
(function (n, t) {
  onload = function () {
    _G.BPT = new Date();
    !_w.sb_ppCPL && t && sb_st(function () {
      t(new Date());
    }, 0);
  }
    ;
}
)(_w.onload, _w.si_PP);
_w.rms.js(
  { 'A:rms:answers:Shared:BingCore.Bundle': '/rp/Bwcx9lYZzDVeFshx5WQGC-o1Sas.br.js' },
  { 'A:rms:answers:Web:SydneyFSCHelper': '/rp/vVcj54Y1uEePuaj76L2qX6HkGig.br.js' },
  { 'A:rms:answers:VisualSystem:ConversationScope': '/rp/SirQHI5m5KAIhKXh7C8whoEm83U.br.js' },
  //{ 'A:rms:answers:CodexBundle:cib-bundle': '/rp/1tz7N7cPo5mo68ojCrW9s1He9HQ.br.js' },
  { 'A:rms:answers:SharedStaticAssets:speech-sdk': '/rp/6slp3E-BqFf904Cz6cCWPY1bh9E.br.js' },
  { 'A:rms:answers:Web:SydneyWelcomeScreenBase':'/rp/t93hmzmmkijvcxxyNOjyR1QdzUI.br.js' },
  { 'A:rms:answers:Web:SydneyWelcomeScreen':'/rp/xJb_8I0a5S58a10IYOcHgMZkwq4.br.js' },
  { 'A:rms:answers:Web:SydneyFullScreenConv': '/rp/SJVe9tj0GAKlXXYTyI0vJ5G-dGM.br.js' },
  );