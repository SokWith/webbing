/* eslint-disable */
(function (n, t) {
  onload = function () {
    _G.BPT = new Date();
    !_w.sb_ppCPL && t && sb_st(function () {
      t(new Date());
    }, 0);
  }
    ;
}
)(_w.onload, _w.si_PP);
_w.rms.js(
  { 'A:rms:answers:Shared:BingCore.Bundle': '/rp/Bwcx9lYZzDVeFshx5WQGC-o1Sas.br.js' },
  { 'A:rms:answers:Web:SydneyFSCHelper': '/rp/h8iJ1DxS_EC8EO0uy_IB7zKwM98.br.js' },
  { 'A:rms:answers:VisualSystem:ConversationScope': '/rp/Hiynn7BhKG6O2vgQFThQvnyzUyM.br.js' },
  { 'A:rms:answers:CodexBundle:cib-bundle': '/rp/3CVA3HVOsO9PskCMrYTMxMDIi1U.br.js' },
  { 'A:rms:answers:SharedStaticAssets:speech-sdk': '/rp/6slp3E-BqFf904Cz6cCWPY1bh9E.br.js' },
  { 'A:rms:answers:Web:SydneyWelcomeScreenBase':'/rp/_Eg7XX2el4yFXBdqXLVFaQjHxOM.br.js' },
  { 'A:rms:answers:Web:SydneyWelcomeScreen':'/rp/MT9w5YvjxYHdcyXSS0tDquzGw2Y.br.js' },
  { 'A:rms:answers:Web:SydneyFullScreenConv': '/rp/X75tNCeKFlgf3t1_IuCM8zL1kd0.br.js' },
  );